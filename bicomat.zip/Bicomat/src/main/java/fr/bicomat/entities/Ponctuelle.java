package fr.bicomat.entities;

public class Ponctuelle {

}
