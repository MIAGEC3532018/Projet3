package fr.bicomat.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("CPT_CH")
public class Compte_Cheque extends Compte{
	private double taux;

	public Compte_Cheque() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Compte_Cheque(int numecompte, double solde, double taux) {
		super(numecompte, solde);
		this.taux = taux;
	}



}
