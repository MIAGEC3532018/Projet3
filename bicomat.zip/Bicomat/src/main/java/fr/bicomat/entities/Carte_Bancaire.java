package fr.bicomat.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity

public class Carte_Bancaire implements Serializable {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String  numcarte;
	private String typecarte;
	private Date echeance;
	private String codecrypto;
	@ManyToOne
	@JoinColumn(name="CODE_CLI")
	private Client utilise;
	public Carte_Bancaire() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getNumcarte() {
		return numcarte;
	}
	public void setNumcarte(String numcarte) {
		this.numcarte = numcarte;
	}
	public String getTypecarte() {
		return typecarte;
	}
	public void setTypecarte(String typecarte) {
		this.typecarte = typecarte;
	}
	public Date getEcheance() {
		return echeance;
	}
	public void setEcheance(Date echeance) {
		this.echeance = echeance;
	}
	public String getCodecrypto() {
		return codecrypto;
	}
	public void setCodecrypto(String codecrypto) {
		this.codecrypto = codecrypto;
	}
	
	public Carte_Bancaire(String numcarte, String typecarte, Date echeance, String codecrypto, Client utilise) {
		super();
		this.numcarte = numcarte;
		this.typecarte = typecarte;
		this.echeance = echeance;
		this.codecrypto = codecrypto;
		this.utilise = utilise;
	}

	public Client getUtilise() {
		return utilise;
	}

	public void setUtilise(Client utilise) {
		this.utilise = utilise;
	}
	
	
	

}
