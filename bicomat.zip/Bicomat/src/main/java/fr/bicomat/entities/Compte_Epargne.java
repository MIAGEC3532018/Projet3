package fr.bicomat.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("CPT_EP")
public class Compte_Epargne extends Compte {
	private double decouvert;

	public Compte_Epargne() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Compte_Epargne(int numecompte, double solde, double decouvert) {
		super(numecompte, solde);
		this.decouvert = decouvert;
	}

	public double getDecouvert() {
		return decouvert;
	}

	public void setDecouvert(double decouvert) {
		this.decouvert = decouvert;
	}



	

}
