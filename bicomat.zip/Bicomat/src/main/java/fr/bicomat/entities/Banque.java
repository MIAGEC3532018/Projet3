package fr.bicomat.entities;

public class Banque {

}
