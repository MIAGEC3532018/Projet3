package fr.bicomat.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("Tiers")
public class Tiers extends Client {

	public Tiers() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Tiers(String nom, String prenom, String adressmail) {
		super(nom, prenom, adressmail);
		// TODO Auto-generated constructor stub
	}





}
