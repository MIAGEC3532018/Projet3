package fr.bicomat.entities;

public class Operation {

}
