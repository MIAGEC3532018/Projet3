package fr.bicomat.entities;

public class Differee {

}
