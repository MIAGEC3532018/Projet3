package fr.bicomat.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@DiscriminatorValue("Interne")
public class Interne extends Client {
	
	private String login;
	private String motpass;
	private int anneearrivee;
	private String numcontrat;
	private String agency;
	private String numportable;
	@ManyToOne
	@JoinColumn(name="typeclient2")
	private Conseiller conseille;
	public Interne() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Interne(String nom, String prenom, String adressmail, String login, String motpass, int anneearrivee,
			String numcontrat, String agency, String numportable, Conseiller conseille) {
		super(nom, prenom, adressmail);
		this.login = login;
		this.motpass = motpass;
		this.anneearrivee = anneearrivee;
		this.numcontrat = numcontrat;
		this.agency = agency;
		this.numportable = numportable;
		this.conseille = conseille;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getMotpass() {
		return motpass;
	}
	public void setMotpass(String motpass) {
		this.motpass = motpass;
	}
	public int getAnneearrivee() {
		return anneearrivee;
	}
	public void setAnneearrivee(int anneearrivee) {
		this.anneearrivee = anneearrivee;
	}
	public String getNumcontrat() {
		return numcontrat;
	}
	public void setNumcontrat(String numcontrat) {
		this.numcontrat = numcontrat;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public String getNumportable() {
		return numportable;
	}
	public void setNumportable(String numportable) {
		this.numportable = numportable;
	}
	public Conseiller getConseille() {
		return conseille;
	}
	public void setConseille(Conseiller conseille) {
		this.conseille = conseille;
	}
	






	

}
