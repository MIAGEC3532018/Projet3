package fr.bicomat.entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="typeCompte",discriminatorType=DiscriminatorType.STRING,length=5)
public abstract class Compte  implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int numecompte;
	private double solde;
	@ManyToOne
	@JoinColumn(name="CODE_CLI")
	private Client possede;
/*	@ManyToOne
	@JoinColumn(name="CODE_BQ")
	private Banque banque;*/
	/*@OneToMany(mappedBy="concerne",fetch=FetchType.LAZY)
	private Collection<Operation> collection;*/
	public Compte() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Compte(int numecompte, double solde) {
		super();
		this.numecompte = numecompte;
		this.solde = solde;
	
	}
	public int getNumecompte() {
		return numecompte;
	}
	public void setNumecompte(int numecompte) {
		this.numecompte = numecompte;
	}
	public double getSolde() {
		return solde;
	}
	public void setSolde(double solde) {
		this.solde = solde;
	}
	public Client getPossede() {
		return possede;
	}
	public void setPossede(Client possede) {
		this.possede = possede;
	}
/*	public Collection<Operation> getCollection() {
		return collection;
	}
	public void setCollection(Collection<Operation> collection) {
		this.collection = collection;
	}
*/


}
