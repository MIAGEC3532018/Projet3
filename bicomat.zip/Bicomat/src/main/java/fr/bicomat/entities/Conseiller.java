package fr.bicomat.entities;

import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Conseiller {
	@Id 
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idconseil;
	private String nomConseil;
	private String prenomConseil;
	@OneToMany(mappedBy="conseille",fetch=FetchType.LAZY)
	private Collection<Interne> internes;
	public Conseiller() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Conseiller( String nomConseil, String prenomConseil) {
		super();
		
		this.nomConseil = nomConseil;
		this.prenomConseil = prenomConseil;
	}
	public Collection<Interne> getInternes() {
		return internes;
	}
	public void setInternes(Collection<Interne> internes) {
		this.internes = internes;
	}
	public String getNomConseil() {
		return nomConseil;
	}
	public void setNomConseil(String nomConseil) {
		this.nomConseil = nomConseil;
	}
	public String getPrenomConseil() {
		return prenomConseil;
	}
	public void setPrenomConseil(String prenomConseil) {
		this.prenomConseil = prenomConseil;
	}
	public Long getIdconseil() {
		return idconseil;
	}
	public void setIdconseil(Long idconseil) {
		this.idconseil = idconseil;
	}
	

}
