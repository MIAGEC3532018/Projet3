package fr.bicomat.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import fr.bicomat.DAO.ClientRepository;
import fr.bicomat.DAO.ConseillerRepository;
import fr.bicomat.entities.Client;
import fr.bicomat.entities.Conseiller;
import fr.bicomat.entities.Interne;
import fr.bicomat.entities.Tiers;



@Controller
public class ClientController {
	@Autowired
	private ClientRepository clientRepository;
	@Autowired
	private ConseillerRepository conseillerRepository;
	
	@RequestMapping(value="/saveInterne")
	public String saveInterne(Model model,
			@Valid  Interne i,
			BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return "newinterne";
		clientRepository.save(i);
		
		return "redirect:/";
		
	}
	
	@RequestMapping(value="/saveTiers")
	public String save(Model model,
			@Valid Tiers t,
			BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return "newtiers";
		clientRepository.save(t);
		
		return "redirect:/";
		
	}
	
	@RequestMapping(value="/newinterne")
	public String forminterne(Model model) {
		model.addAttribute("conseiller", conseillerRepository.findAll());
		model.addAttribute("interne", new Interne());
		return "newinterne";
	}
	@RequestMapping(value="/newtiers")
	
	public String form(Model model) {
		model.addAttribute("tiers", new Tiers());
		return "newtiers";
	}


	
	
	
	
	
}
