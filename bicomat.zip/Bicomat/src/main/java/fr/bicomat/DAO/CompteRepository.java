package fr.bicomat.DAO;

public interface CompteRepository {

}
