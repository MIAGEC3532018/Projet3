package fr.bicomat.DAO;

public interface OperationRepository {

}
