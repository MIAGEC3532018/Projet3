package fr.bicomat.DAO;

public interface BanqueRepository {

}
