package fr.bicomat.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.bicomat.entities.Conseiller;

public interface ConseillerRepository extends JpaRepository<Conseiller, Long> {

}
