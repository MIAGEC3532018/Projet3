package fr.bicomat.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fr.bicomat.entities.Carte_Bancaire;
@Repository
public interface CarteBancaireRepository extends JpaRepository<Carte_Bancaire, String>{

}
