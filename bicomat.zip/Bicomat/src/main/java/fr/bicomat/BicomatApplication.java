package fr.bicomat;

import org.hibernate.dialect.InterbaseDialect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import fr.bicomat.DAO.ClientRepository;
import fr.bicomat.DAO.ConseillerRepository;
import fr.bicomat.entities.Conseiller;
import fr.bicomat.entities.Interne;
import fr.bicomat.entities.Tiers;

@SpringBootApplication
public class BicomatApplication {

	public static void main(String[] args) {
		SpringApplication.run(BicomatApplication.class, args);
	}
}
